import React from 'react';
import './assets/HomeVistaEvento.css'
import Afiche from'./imgs/competencia.jpg'

const HomeVistaEvento = () => {
  return (
    <div className="body">
        <div className="eventos">
          <div className="evento_izquierda">
            <div className="div_img">
              <img className="imagen-izquierda" src={Afiche} alt="Imagen Izquierda" />
            </div>
          <img src="" alt="flecha-izquierda" className="boton-izquierda" />
          </div>

          <div className="evento_actual">
            <h3 className="titulo_evento">Título evento</h3>
            <div className='img-central'>
              <img src={Afiche} alt="Imagen del Evento" className="imagen_evento" />
            </div>
            

            <button className="boton_mas_informacion" type="button">
              Más información
            </button>
          </div>

          <div className="evento_derecha">
            <img src={Afiche} alt="flecha-derecha" className="boton-derecha" />
            <div className="div_img">
              <img className="imagen-derecha" src={Afiche} alt="Imagen Derecha" />
            </div>
          </div>
        </div>

        <hr />

        <div className="sobre_icpc">
          <h3>Competición internacional universitaria de programación ICPC</h3>
          <div className="descripcion_sobre_icpc">
            <p>
              La ICPC se inicia en 1970, como un programa de innovación para incrementar ambición, aptitud de
              resolución de problemas, y la oportunidad para estudiantes fuertes en el campo de la computación. Con el
              tiempo, el concurso se convirtió en una competencia de varios niveles con la primera ronda de campeonato
              realizada en 1977; desde entonces el concurso se ha expandido a una colaboración mundial de universidades
              que albergan competencias regionales que hacen avanzar a los equipos a la ronda final anual del campeonato
              mundial, el ICPC World Finals.
            </p>
          </div>
        </div>

    </div>
  );
};

export default HomeVistaEvento;
