import React from 'react';
import './assets/navbar.css';

const Menu = () => {
  return (
  <nav className="navbar">
      <a href="./home">
        <img src="   https://cdn-icons-png.flaticon.com/512/8280/8280362.png " alt="Usuario" />
        <div>
          <p>Inicio</p>
          <div className="line"></div>
        </div>
      </a>
      
      <a href="./CrearEvento">
      <img src="   https://cdn-icons-png.flaticon.com/512/10746/10746540.png " alt="Usuario" />
      <div>
        <p>Crear Evento
        </p>
        <div className="line"></div>
      </div>
      </a>

      <a href="./CrearTipoEvento">
      <img src="   https://cdn-icons-png.flaticon.com/512/9790/9790435.png " alt="Usuario" />
      <div>
        <p>Crear Tipo Evento
        </p>
        <div className="line"></div>
      </div>
      </a>

      <a href="./CrearCompetencia">
      <img src="   https://cdn-icons-png.flaticon.com/512/6851/6851277.png " alt="Usuario" />
      <div>
        <p>Crear Competencias
        </p>
        <div className="line"></div>
      </div>
      </a>
  </nav>
  );
};

export default Menu;