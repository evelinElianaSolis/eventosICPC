import React, { useState } from 'react';
import axios from 'axios';
import '../components/assets/FormCrearEvento.css';

const EventForm = () => {
  const [titulo, setTitulo] = useState('');
  const [fechaInicio, setFechaInicio] = useState('');
  const [fechaFin, setFechaFin] = useState('');
  const [ubicacion, setUbicacion] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [privacidad, setPrivacidad] = useState('Competición'); // Establecer valor inicial para privacidad
  const [requisitos, setRequisitos] = useState('');
  const [horaEvento, setHoraEvento] = useState('');
  const [imagen, setImagen] = useState(null);
  const [idPersona, setIdPersona] = useState(''); // Nuevo estado para idPersona

  const handleTituloChange = (e) => {
    setTitulo(e.target.value);
  };

  const handleFechaInicioChange = (e) => {
    setFechaInicio(e.target.value);
  };

  const handleFechaFinChange = (e) => {
    setFechaFin(e.target.value);
  };

  const handleUbicacionChange = (e) => {
    setUbicacion(e.target.value);
  };

  const handleDescripcionChange = (e) => {
    setDescripcion(e.target.value);
  };

  const handleRequisitosChange = (e) => {
    setRequisitos(e.target.value);
  };

  const handlePrivacidadChange = (e) => {
    setPrivacidad(e.target.value);
  };

  const handleHoraEventoChange = (e) => {
    setHoraEvento(e.target.value);
  };

  const handleImagenChange = (e) => {
    const file = e.target.files[0];
    setImagen(file);
  };

  const handleIdPersonaChange = (e) => {
    setIdPersona(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('titulo', titulo);
    formData.append('fechaInicio', fechaInicio);
    formData.append('fechaFin', fechaFin);
    formData.append('ubicacion', ubicacion);
    formData.append('descripcion', descripcion);
    formData.append('requisitos', requisitos);
    formData.append('TipoDeEvento', privacidad);
    formData.append('horaEvento', horaEvento);
    formData.append('imagen', imagen);
    formData.append('idPersona', idPersona);

    try {
      await axios.post('http://localhost:8000/api/eventos', formData);
      console.log('Evento creado con éxito');
    } catch (error) {
      console.error('Error al crear evento', error);
    }
  };


  return (
    <form onSubmit={handleSubmit} className="tweet-composer">
        
      <div className="composer-form">
        <label htmlFor="titulo">tipo formulario</label>
        <input
          type="text"
          id="titulo"
          name="titulo"
          placeholder="Título"
          value={titulo}
          onChange={handleTituloChange}
          required
        />

        <div className="Fecha">
          <div className="FechaInicio">
            <label htmlFor="fecha-inicio">Fecha Inicio</label>
            <input
              className="FechaDesing"
              type="date"
              id="fecha-inicio"
              name="fecha-inicio"
              value={fechaInicio}
              onChange={handleFechaInicioChange}
              required
            />
          </div>

          <div className="FechaFinal">
            <label htmlFor="fecha-fin">Fecha Fin</label>
            <input
              className="FechaDesing"
              type="date"
              id="fecha-fin"
              name="fecha-fin"
              value={fechaFin}
              onChange={handleFechaFinChange}
              required
            />
          </div>
        </div>

        
        <div className="container">
          <div className="other-elements"></div>
          <div>
            <button className="tweet-button" type="submit">
              Cancelar
            </button>
            <button className="tweet-button" type="submit">
              Guardar
            </button>

          </div>
        </div>
      </div>
    </form>
  );
};

export default EventForm;
