import React from 'react';
import './assets/HomeVistaEvento.css'

const HomeVistaEvento = () => {
  return (
    <div>
        {/*vista de Competencia */}
        <p>Crear Competencia</p>
    </div>
  );
};

export default HomeVistaEvento;