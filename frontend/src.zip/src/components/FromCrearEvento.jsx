import React, { useState } from 'react';
import axios from 'axios';
import '../components/assets/FormCrearEvento.css';

const EventForm = () => {
  const [tituloEvento, setTituloEvento] = useState('holaa');
  const [fechaInicio, setFechaInicio] = useState('2023-10-15');
  const [fechaFin, setFechaFin] = useState('2023-10-20');
  // const [ubicacion, setUbicacion] = useState('');
  const [descripcion, setDescripcion] = useState('Descripción del evento');
  const [imagen, setImagen] = useState('URL del afiche del evento');
  const [estado, setEstado] = useState(true);
  // const [privacidad, setPrivacidad] = useState('Competición');
  const [horaEvento, setHoraEvento] = useState('15:00');
  const [requisitos, setRequisitos] = useState('Requisitos del evento');
  const [idAdministrador, setIdAdministrador] = useState('1');

  const handleTituloChange = (e) => setTituloEvento(e.target.value);
  const handleFechaInicioChange = (e) => setFechaInicio(e.target.value);
  const handleFechaFinChange = (e) => setFechaFin(e.target.value);
  // const handleUbicacionChange = (e) => setUbicacion(e.target.value);
  const handleDescripcionChange = (e) => setDescripcion(e.target.value);
  const handleRequisitosChange = (e) => setRequisitos(e.target.value);
  const handleEstadoChange = (e) => setEstado(e.target.value);
  const handleHoraEventoChange = (e) => setHoraEvento(e.target.value);
  const handleImagenChange = (e) => setImagen(e.target.value);
  const handleIdAdministradorChange = (e) => setIdAdministrador(e.target.value);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await axios.post('http://localhost:8000/api/evento', {
        tituloEvento: tituloEvento,
        fechaInicioEvento: fechaInicio,
        fechaFinEvento: fechaFin,
        descripcionEvento: descripcion,
        aficheEvento: imagen,
        estadoEvento: estado ? 1 : 0,
        horaInicioEvento: horaEvento,
        requisitosEvento: requisitos,
        idAdministrador: idAdministrador
      });
      console.log('Evento creado con éxito');

    } catch (error) {
   
      // Manejar el error de Axios de manera más detallada
      if (error.response) {
        // La solicitud se realizó, pero el servidor respondió con un código de estado fuera del rango 2xx
        console.error('Respuesta del servidor con error:', error.response.data);
        console.error('Código de estado HTTP:', error.response.status);
      } else if (error.request) {
        // La solicitud se hizo, pero no se recibió respuesta
        console.error('No se recibió respuesta del servidor:', error.request);
      } else {
        // Algo sucedió en la configuración de la solicitud que causó el error
        console.error('Error durante la configuración de la solicitud:', error.message);
      }
    }
  };

  return (
    
    <form onSubmit={handleSubmit} className="tweet-composer">
      <div className="composer-form">
        <label htmlFor="tituloEvento">Titulo del Evento</label>
        <input
          type="text"
          id="tituloEvento"
          name="tituloEvento"
          placeholder="tituloEvento"
          value={tituloEvento}
          onChange={handleTituloChange}
          required
        />

        <div className="Fecha">
          <div className="FechaInicio">
            <label htmlFor="fecha-inicio">Fecha Inicio</label>
            <input
              className="FechaDesing"
              type="date"
              id="fecha-inicio"
              name="fecha-inicio"
              value={fechaInicio}
              onChange={handleFechaInicioChange}
              required
            />
          </div>

          <div className="FechaFinal">
            <label htmlFor="fecha-fin">Fecha Fin</label>
            <input
              className="FechaDesing"
              type="date"
              id="fecha-fin"
              name="fecha-fin"
              value={fechaFin}
              onChange={handleFechaFinChange}
              required
            />
          </div>
        </div>

        {/* <label htmlFor="ubicacion">Ubicación</label>
        <input
          type="text"
          id="ubicacion"
          name="ubicacion"
          placeholder="Ubicación"
          value={ubicacion}
          onChange={handleUbicacionChange}
        />
        */}

        <label htmlFor="descripcion">Descripción</label>
        <textarea
          id="descripcion"
          name="descripcion"
          placeholder="Descripción"
          rows="4"
          value={descripcion}
          onChange={handleDescripcionChange}
          required
        ></textarea>

        <label htmlFor="requisitos">Requisitos del evento</label>
        <textarea
          id="requisitos"
          name="requisitos"
          placeholder="Requisitos"
          rows="4"
          value={requisitos}
          onChange={handleRequisitosChange}
          required
        ></textarea>

        <div className="img1">
          <div className="EstadoEvento">
            <label htmlFor="estado">Tipo de evento</label>
            <select
              id="estado"
              name="estado"
              value={estado}
              onChange={handleEstadoChange}
            >
              <option value="true">true</option>
              <option value="false">false</option>
            </select>
          </div>

          <div className="horaEvento">
            <label htmlFor="horaEvento">Hora</label>
            <input
              type="time"
              id="horaEvento"
              name="horaEvento"
              value={horaEvento}
              onChange={handleHoraEventoChange}
              required
            />
          </div>
        </div>

        <label htmlFor="imagen">URL del afiche del evento</label>
        <input
          type="text"
          id="imagen"
          name="imagen"
          value={imagen}
          onChange={handleImagenChange}
        />

        <label htmlFor="IdAdministrador">ID del Administrador</label>
        <input
          type="text"
          id="IdAdministrador"
          name="IdAdministrador"
          placeholder="IdAdministrador"
          value={idAdministrador}
          onChange={handleIdAdministradorChange}
          required
        />

        <div className="container">
          <div className="other-elements"></div>
          <div>
            <button className="tweet-button" type="submit">
              Cancelar
            </button>
            <button className="tweet-button" type="submit">
              Guardar
            </button>
          </div>
        </div>
      </div>
    </form>
  );
};

export default EventForm;
